//import stuff
import React from 'react';
import {View, Text, Image, TextInput, Button} from 'react-native';

const logo = {
  uri: 'https://reactnative.dev/img/tiny_logo.png',
  width: 64,
  height: 64,
};

//create shit
class App extends React.Component{
	state = {
    text: "",
    todo: []
  }
  addTodo = () =>{
    var newTodo = this.state.text;
    var arr = this.state.todo;
    arr.push(newTodo);
    this.setState({todo: arr});
  }
  renderTodos = () =>{
    return this.state.todo.map(t=>{
      return (
        <Text key={t}>{t}</Text>
      )
    })
  }
  render(){
		return(
		<View style={styles.viewStyle}>
    <Image source={logo} />
			<Text style={styles.setFontSizeOne}>        </Text> 
        <Button
        title="Cardiovascular"
        color="#00a152"
        />
        <Text style={styles.setFontSizeTwo}>      </Text> 
        <Button
        title="Women's Health"
        color="#00a152"
        />
        <Text style={styles.setFontSizeTwo}>     </Text> 
        <Button
        title="Men's Health"
        color="#00a152"
        />
        <Text style={styles.setFontSizeTwo}>     </Text>
        <Button
        title="Autoimmune"
        color="#00a152"
        />
        {this.renderTodos()}
		</View>
		)
	}
}

const styles = {
  viewStyle: {
    flex: 1, 
    justifyContent: 'center',
  },
  setFontSizeOne: {
    fontSize: 30 
  },
  setFontSizeTwo: {
    fontSize: 25 
  },
}

export default App;