import React, {Component} from 'react';
import {StyleSheet, View, Image, Text} from 'react-native';


export default class App extends Component {
  render() {
    return (
      <View style={styles.container}>
      <View style={styles.logoContainer}>
      <Image
      style={styles.logo}
      source={require('snack-icon.png')}
      />

      <Text style={styles.title}>
      </View>
      <View style={styles.formContainer}>
      </View>
      </View>
    )
  }
}