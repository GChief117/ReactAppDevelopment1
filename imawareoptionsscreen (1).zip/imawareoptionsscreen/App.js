//import stuff
import React from 'react';
import {View, Text, TextInput, Button} from 'react-native';


//create shit
class App extends React.Component{
	state = {
    text: "",
    todo: []
  }
  addTodo = () =>{
    var newTodo = this.state.text;
    var arr = this.state.todo;
    arr.push(newTodo);
    this.setState({todo: arr});
  }
  renderTodos = () =>{
    return this.state.todo.map(t=>{
      return (
        <Text key={t}>{t}</Text>
      )
    })
  }
  render(){
		return(
		<View style={styles.viewStyle}>
			<Text style={styles.setFontSizeOne}>        </Text> 
        <Button
        title="BUY A KIT"
        color="#00a152"
        />
        <Text style={styles.setFontSizeTwo}>      </Text> 
        <Button
        title="REGISTRATION"
        color="#00a152"
        />
        <Text style={styles.setFontSizeTwo}>     </Text> 
        <Button
        title="SEE RESULTS"
        color="#00a152"
        />
        {this.renderTodos()}
		</View>
		)
	}
}

const styles = {
  viewStyle: {
    flex: 1, 
    justifyContent: 'center'
  },
  setFontSizeOne: {
    fontSize: 30 
  },
  setFontSizeTwo: {
    fontSize: 25 
  },
}

//export stuff


export default App;