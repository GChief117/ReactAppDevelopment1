//import stuff
import React from 'react';
import {View, Text, TextInput, Button} from 'react-native';


//create shit
class App extends React.Component{
	render(){
		return(
		<View style={styles.viewStyle}>
			<Text>This app is great!</Text> 
      <TextInput
        style={styles.inputStyle}
        />
		</View>
		)
	}
}

const styles = {
  viewStyle: {
    flex: 1, 
    alignItems: 'center', 
    justifyContent: 'center'
  },
  inputStyle:{
    height: 40,
    borderColor: "green",
    borderWidth: 1
  }
}

//export stuff


export default App;