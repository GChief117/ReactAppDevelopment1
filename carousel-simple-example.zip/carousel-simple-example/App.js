import * as React from 'react';
import {
  Text, 
  View,
  SafeAreaView } from 'react-native';

import Carousel from 'react-native-snap-carousel';

export default class App extends React.Component {

 
    constructor(props){
        super(props);
        this.state = {
          carouselItems: [
          {
              title:"48%",
              text: "Of adults in the United States suffer from heart disease disease",
          },
          {
              title:"#1 Cause of Death",
              text: "In the US is cardiovascular disease",
          },
          {
              title:"Symptoms",
              text:("Chest pain, Leg Pain, Fatigue, Palpatations, Weight Gain"),
          },
        ]
      }
    }

    _renderItem({item,index}){
        return (
          <View style={{
              backgroundColor:'floralwhite',
              borderColor: '#00a152',
              borderRadius: 5,
              borderWidth: 8,
              height: 250,
              padding: 50,
              marginLeft: 25,
              marginRight: 25, }}>
            <Text style={{fontSize: 25}}>{item.title}</Text>
            <Text>{item.text}</Text>
          </View>

        )
    }
    

    render() {
        return (
          <SafeAreaView style={{flex: 1, backgroundColor:'White', paddingTop: 50, }}>
            <View style={{ flex: 1, flexDirection:'row', justifyContent: 'center', }}>
                <Carousel
                  layout={"default"}
                  ref={ref => this.carousel = ref}
                  data={this.state.carouselItems}
                  sliderWidth={300}
                  itemWidth={300}
                  renderItem={this._renderItem}
                  onSnapToItem = { index => this.setState({activeIndex:index}) } />
            </View>
          </SafeAreaView>
        );
    }
}

