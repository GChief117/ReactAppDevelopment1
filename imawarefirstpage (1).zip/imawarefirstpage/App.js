//import stuff
import React from 'react';
import {View, Text, TextInput, Button} from 'react-native';


//create shit
class App extends React.Component{
	state = {
    text: "",
    todo: []
  }
  addTodo = () =>{
    var newTodo = this.state.text;
    var arr = this.state.todo;
    arr.push(newTodo);
    this.setState({todo: arr});
  }
  renderTodos = () =>{
    return this.state.todo.map(t=>{
      return (
        <Text key={t}>{t}</Text>
      )
    })
  }
  render(){
		return(
		<View style={styles.viewStyle}>
			<Text style={styles.setFontSizeOne}>Welcome to Imaware</Text> 
        <Button
        title="LOGIN"
        color="green"
        />
        <Text style={styles.setFontSizeTwo}>No account?</Text> 
        <Button
        title="BUY KIT"
        color="green"
        />
        {this.renderTodos()}
		</View>
		)
	}
}

const styles = {
  viewStyle: {
    flex: 1, 
    alignItems: 'center', 
    justifyContent: 'center'
  },
  setFontSizeOne: {
    fontSize: 30 
  },
  setFontSizeTwo: {
    fontSize: 25 
  },
}

//export stuff


export default App;